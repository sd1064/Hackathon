# current position
# known locations
# print current board
# move
import time
from Constants.constants import constants

class player:
    currentPosition = [0,0]
    knownLocations  = [] #[[ROW,COL,TYPE]]
    board=[]
    DECIDE_TIME = 3

    def __init__(self,board,DECIDE_TIME):
        self.board=board
        self.currentPosition[1]=int(len(board.board)/2)
        self.DECIDE_TIME = DECIDE_TIME

    def printCurrentBoard(self):
        fogOfWarBoard=[]
        for i in range(0,len(self.board.board)):
            row=[]
            for i in range(0,len(self.board.board)):
                row.append(constants.UNKNOWN)
            fogOfWarBoard.append(row)

        for i in range(0,len(self.knownLocations)):
            fogOfWarBoard[self.knownLocations[i][0]][self.knownLocations[i][1]]=self.knownLocations[i][2]
        fogOfWarBoard[self.currentPosition[0]][self.currentPosition[1]]=constants.PLAYER
        print "\n"
        for i in range(0,len(fogOfWarBoard)):
            print fogOfWarBoard[i]
        print "\n"

    def scanForMine(self):
        self.knownLocations = self.knownLocations + self.board.scanForMine(self.currentPosition[0],self.currentPosition[1])


    def decideMove(self):
        t_end = time.time() + self.DECIDE_TIME
        finished=False
        while time.time() < t_end and finished==False:
            trys=3
            if trys==0:
                return False
            else:
                ############### MODIFY ##################
                move=constants.FORWARD
                ############## MODIFY ##################
                if self.check_valid_move(move):
                    finished = True
                    return self.move(move)
                else:
                    trys=trys-1

    def check_valid_move(self,move):
        #check move not out of bounds
        return True

    def move(self,moveType):
            if moveType==constants.LEFT:
                newRow=self.currentPosition[0]
                newCol=self.currentPosition[1]-1
            elif moveType==constants.RIGHT:
                newRow=self.currentPosition[0]
                newCol=self.currentPosition[1]+1
            elif moveType==constants.FORWARD:
                newRow=self.currentPosition[0]+1
                newCol=self.currentPosition[1]
            self.currentPosition[0]=newRow
            self.currentPosition[1]=newCol

            print self.board.board[self.currentPosition[0]][self.currentPosition[1]]

            if (self.board.board[self.currentPosition[0]][self.currentPosition[1]]==constants.MINE):
                return False
