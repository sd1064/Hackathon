class constants:
    MINE    = "-M-"
    EMPTY   = "-O-"
    UNKNOWN = "-?-"
    PLAYER  = "-P-"

    FORWARD = "FORWARD"
    LEFT    = "LEFT"
    RIGHT   = "RIGHT"
